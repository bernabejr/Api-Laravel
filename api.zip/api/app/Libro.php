<?php

namespace App;

use App\Prestamo;
use Illuminate\Database\Eloquent\Model;

class Libro extends Model
{
    protected $fillable = [
        'titulo', 'descripcion'
    ];

    public function prestar(){
        return $this->hasMany(Prestamo::class);
    }
}
