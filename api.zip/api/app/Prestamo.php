<?php

namespace App;

use App\User;
use App\Libro;
use Illuminate\Database\Eloquent\Model;

class Prestamo extends Model
{
    protected $fillable = [
        'id_user', 'id_libro'
    ];

    public function libros(){
        return $this->belongsToMany(Libro::class);
    }

    public function usuarios(){
        return $this->belongsToMany(User::class);
    }

    public $timestamps = false;
}
