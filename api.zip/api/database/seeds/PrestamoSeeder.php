<?php

use App\Prestamo;
use Illuminate\Database\Seeder;

class PrestamoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Prestamo::create([
            'id_user' => '1',
            'id_libro' => '2'
        ]);

        Prestamo::create([
            'id_user' => '6',
            'id_libro' => '3'
        ]);
    }
}
