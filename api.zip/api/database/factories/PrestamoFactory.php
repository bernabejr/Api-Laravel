<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Prestamo;
use Faker\Generator as Faker;

$factory->define(Prestamo::class, function (Faker $faker) {
    return [
        //
    ];
});
